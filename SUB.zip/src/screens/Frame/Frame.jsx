import React from "react";

export const Frame = () => {
  return (
    <div className="flex flex-col h-[7238px] items-start relative">
      <div className="flex h-[960px] items-center justify-between pl-[120px] pr-0 py-0 relative self-stretch w-full bg-[#191919] overflow-hidden">
        <div className="flex flex-col min-w-[762px] max-w-[816px] items-start justify-center gap-16 relative flex-1 grow z-[1]">
          <div className="flex flex-col items-start gap-6 relative self-stretch w-full flex-[0_0_auto]">
            <div className="flex items-start gap-2.5 relative self-stretch w-full flex-[0_0_auto]">
              <div className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-[#f3f3f3] text-7xl tracking-[-2.88px] leading-[normal]">
                NUTRIGOAL
              </div>
            </div>
            <p className="opacity-50 text-white relative self-stretch [font-family:'Inter',Helvetica] font-normal text-2xl tracking-[-0.96px] leading-[normal]">
              Nutrition and Diet Planner with Health Goals
              <br />
              Creating a personalized nutrition and diet plan is essential for achieving health goals, whether it&#39;s
              weight loss, maintenance, or overall wellness. Here’s a comprehensive overview of how to effectively plan
              your meals based on individual health objectives.
            </p>
          </div>
          <button className="all-[unset] box-border flex items-start gap-2.5 relative self-stretch w-full flex-[0_0_auto]">
            <button className="all-[unset] box-border flex max-w-xs items-center justify-center gap-2.5 p-6 relative flex-1 grow bg-white rounded-[10px] overflow-hidden">
              <button className="all-[unset] box-border relative flex-1 mt-[-7.00px] [font-family:'Inter',Helvetica] font-bold text-[#0d0d0d] text-2xl text-center tracking-[-0.96px] leading-[normal]">
                Get Started
              </button>
            </button>
          </button>
        </div>
        <div className="flex flex-wrap items-start justify-around gap-[10px_10px] pl-0 pr-[238px] py-[407px] relative flex-1 grow mt-[-556.00px] mb-[-556.00px] z-0 bg-[url(/static/img/map-wrapper.svg)] bg-cover bg-[50%_50%]">
          <img
            className="relative w-[984px] h-[960px] mr-[-238.00px] object-cover"
            alt="Pexels karolina"
            src="/img/pexels-karolina-grabowska-5714507-1.png"
          />
        </div>
      </div>
      <div className="flex flex-col items-start gap-12 p-[120px] relative self-stretch w-full flex-[0_0_auto] bg-white">
        <div className="flex flex-col items-start gap-6 relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex max-w-[1060px] items-start gap-2.5 relative self-stretch w-full flex-[0_0_auto]">
            <div className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-[#191919] text-7xl tracking-[-2.88px] leading-[normal]">
              Key Features
            </div>
          </div>
          <p className="opacity-60 text-black relative self-stretch [font-family:'Inter',Helvetica] font-normal text-2xl tracking-[-0.96px] leading-[normal]">
            Discover the powerful features of our expense tracker web app.
          </p>
        </div>
        <div className="flex flex-wrap items-start justify-center gap-[4px_4px] relative self-stretch w-full flex-[0_0_auto] overflow-hidden">
          <div className="flex flex-col min-w-[400px] max-w-[610px] items-start justify-center gap-3 p-6 relative flex-1 grow bg-[#f7f7f7] rounded-[10px] overflow-hidden">
            <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-black text-[40px] tracking-[-1.60px] leading-[normal]">
              UNDERSTANDING YOUR GOALS
            </div>
            <p className="relative self-stretch opacity-50 [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
              Effortlessly categorize your expenses for better organization.
            </p>
          </div>
          <div className="flex flex-col min-w-[400px] max-w-[610px] items-start justify-center gap-3 p-6 relative flex-1 grow bg-[#f7f7f7] rounded-[10px] overflow-hidden">
            <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-black text-[40px] tracking-[-1.60px] leading-[normal]">
              MEAL PLANNING STEPS
            </div>
            <p className="relative self-stretch opacity-50 [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
              Stay on top of your finances by tracking your budget i&nbsp;&nbsp;n real-time.
            </p>
          </div>
          <div className="flex flex-col min-w-[400px] max-w-[610px] items-start justify-center gap-3 p-6 relative flex-1 grow bg-[#f7f7f7] rounded-[10px] overflow-hidden">
            <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-black text-[40px] tracking-[-1.60px] leading-[normal]">
              SAMPLE MEAL PLANS
            </div>
            <p className="relative self-stretch opacity-50 [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
              Generate detailed reports to gain insights into your spending habits.
            </p>
          </div>
        </div>
        <div className="flex flex-col min-w-[400px] max-w-[610px] items-start justify-center gap-3 p-6 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[10px] overflow-hidden">
          <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-black text-[40px] tracking-[-1.60px] leading-[normal]">
            TOOLS AND RESOURCES
          </div>
          <p className="relative self-stretch opacity-50 [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
            Generate detailed reports to gain insights into your spending habits.
          </p>
        </div>
      </div>
      <div className="flex flex-col items-start gap-12 p-[120px] relative self-stretch w-full flex-[0_0_auto] bg-white">
        <div className="max-w-[816px] gap-3 self-stretch w-full flex-[0_0_auto] flex flex-col items-start relative">
          <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-[#191919] text-7xl tracking-[-2.88px] leading-[normal]">
            How It Works
          </div>
          <p className="relative self-stretch opacity-50 [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
            Learn how to use the expense tracker web app with this step-by-step guide.
          </p>
        </div>
        <div className="flex-wrap gap-[32px_0px] flex items-start relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex flex-col min-w-[400px] items-start justify-center gap-3 relative flex-1 grow rounded-[20px] overflow-hidden">
            <div className="flex items-center relative self-stretch w-full flex-[0_0_auto]">
              <div className="flex flex-col w-[82px] items-center justify-center gap-3 px-8 py-6 relative bg-[#191919] rounded-[60px] overflow-hidden">
                <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-bold text-white text-[28px] text-center tracking-[-1.12px] leading-[normal]">
                  1
                </div>
              </div>
              <div className="relative flex-1 grow h-0.5 bg-[#191919]" />
            </div>
            <div className="flex flex-col items-start justify-center gap-2.5 pl-0 pr-6 py-0 relative self-stretch w-full flex-[0_0_auto]">
              <div className="flex flex-col items-start justify-center gap-3 p-8 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[20px] overflow-hidden">
                <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-black text-[40px] tracking-[-1.60px] leading-[normal]">
                  Step 1: Add Expenses
                </div>
                <p className="relative self-stretch opacity-50 [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                  Start by adding your expenses to the app. Enter the amount, category, and date of each expense.
                </p>
              </div>
            </div>
          </div>
          <div className="flex flex-col min-w-[400px] items-start justify-center gap-3 relative flex-1 grow rounded-[20px] overflow-hidden">
            <div className="flex items-center relative self-stretch w-full flex-[0_0_auto]">
              <div className="flex flex-col w-[82px] items-center justify-center gap-3 px-8 py-6 relative bg-[#191919] rounded-[60px] overflow-hidden">
                <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-bold text-white text-[28px] text-center tracking-[-1.12px] leading-[normal]">
                  2
                </div>
              </div>
              <div className="relative flex-1 grow h-0.5 bg-[#191919]" />
            </div>
            <div className="flex flex-col items-start justify-center gap-2.5 pl-0 pr-6 py-0 relative self-stretch w-full flex-[0_0_auto]">
              <div className="flex flex-col items-start justify-center gap-3 p-8 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[20px] overflow-hidden">
                <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-black text-[40px] tracking-[-1.60px] leading-[normal]">
                  Step 2: Set Budgets
                </div>
                <p className="relative self-stretch opacity-50 [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                  Set budgets for different expense categories to help you stay on track. The app will notify you when
                  you&#39;re close to reaching your budget limit.
                </p>
              </div>
            </div>
          </div>
          <div className="flex flex-col min-w-[400px] items-start justify-center gap-3 relative flex-1 grow rounded-[20px] overflow-hidden">
            <div className="flex items-center relative self-stretch w-full flex-[0_0_auto]">
              <div className="flex flex-col w-[82px] items-center justify-center gap-3 px-8 py-6 relative bg-[#191919] rounded-[60px] overflow-hidden">
                <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-bold text-white text-[28px] text-center tracking-[-1.12px] leading-[normal]">
                  3
                </div>
              </div>
              <div className="relative flex-1 grow h-0.5 bg-[#191919]" />
            </div>
            <div className="flex flex-col items-start justify-center gap-2.5 pl-0 pr-6 py-0 relative self-stretch w-full flex-[0_0_auto]">
              <div className="flex flex-col items-start justify-center gap-3 p-8 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[20px] overflow-hidden">
                <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-black text-[40px] tracking-[-1.60px] leading-[normal]">
                  Step 3: Generate Reports
                </div>
                <p className="relative self-stretch opacity-50 [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                  Generate reports to get a clear overview of your expenses. Analyze your spending patterns and make
                  informed financial decisions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col items-start gap-12 p-[120px] relative self-stretch w-full flex-[0_0_auto] bg-white">
        <div className="min-w-[762px] gap-3 self-stretch w-full flex-[0_0_auto] flex flex-col items-start relative">
          <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-[#191919] text-7xl tracking-[-2.88px] leading-[normal]">
            FAQ
          </div>
        </div>
        <div className="flex-col gap-3 flex items-start relative self-stretch w-full flex-[0_0_auto]">
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto] rounded-[20px] overflow-hidden border-2 border-solid border-[#f7f7f7]">
            <div className="flex min-w-[400px] items-center justify-between p-8 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[20px_20px_0px_0px] overflow-hidden">
              <div className="relative w-[1552px] h-[46px]">
                <div className="absolute w-[1552px] -top-px left-0 [font-family:'Inter',Helvetica] font-black text-black text-[38px] tracking-[-1.52px] leading-[normal]">
                  Is my data secure?
                </div>
              </div>
              <div className="relative w-16 h-16 bg-black rounded-[60px] overflow-hidden">
                <div className="absolute top-[11px] left-[22px] [font-family:'Inter',Helvetica] font-black text-white text-3xl text-center tracking-[-1.20px] leading-[normal] whitespace-nowrap">
                  +
                </div>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-8 relative self-stretch w-full flex-[0_0_auto]">
              <p className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                Yes, we take data security very seriously. Our expense tracker web app uses the latest encryption
                technology to ensure that your data is safe and secure.
              </p>
            </div>
          </div>
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto] rounded-[20px] overflow-hidden border-2 border-solid border-[#f7f7f7]">
            <div className="flex min-w-[400px] items-center justify-between p-8 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[20px_20px_0px_0px] overflow-hidden">
              <div className="relative w-[1552px] h-[46px]">
                <p className="absolute w-[1552px] -top-px left-0 [font-family:'Inter',Helvetica] font-black text-black text-[38px] tracking-[-1.52px] leading-[normal]">
                  Can I access my expense data from multiple devices?
                </p>
              </div>
              <div className="relative w-16 h-16 bg-black rounded-[60px] overflow-hidden">
                <div className="absolute top-[11px] left-[22px] [font-family:'Inter',Helvetica] font-black text-white text-3xl text-center tracking-[-1.20px] leading-[normal] whitespace-nowrap">
                  +
                </div>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-8 relative self-stretch w-full flex-[0_0_auto]">
              <p className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                Absolutely! Our expense tracker web app is designed to be accessible from any device with an internet
                connection. You can easily access and manage your expense data from your computer, smartphone, or
                tablet.
              </p>
            </div>
          </div>
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto] rounded-[20px] overflow-hidden border-2 border-solid border-[#f7f7f7]">
            <div className="flex min-w-[400px] items-center justify-between p-8 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[20px_20px_0px_0px] overflow-hidden">
              <div className="relative w-[1552px] h-[46px]">
                <p className="absolute w-[1552px] -top-px left-0 [font-family:'Inter',Helvetica] font-black text-black text-[38px] tracking-[-1.52px] leading-[normal]">
                  What happens if I lose my device?
                </p>
              </div>
              <div className="relative w-16 h-16 bg-black rounded-[60px] overflow-hidden">
                <div className="absolute top-[11px] left-[22px] [font-family:'Inter',Helvetica] font-black text-white text-3xl text-center tracking-[-1.20px] leading-[normal] whitespace-nowrap">
                  +
                </div>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-8 relative self-stretch w-full flex-[0_0_auto]">
              <p className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                Don&#39;t worry! Your expense data is securely stored in the cloud, so even if you lose your device, you
                can still access your data from any other device. Just log in to your account and all your expense data
                will be there.
              </p>
            </div>
          </div>
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto] rounded-[20px] overflow-hidden border-2 border-solid border-[#f7f7f7]">
            <div className="flex min-w-[400px] items-center justify-between p-8 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[20px_20px_0px_0px] overflow-hidden">
              <div className="relative w-[1552px] h-[46px]">
                <div className="absolute w-[1552px] -top-px left-0 [font-family:'Inter',Helvetica] font-black text-black text-[38px] tracking-[-1.52px] leading-[normal]">
                  Is customer support available?
                </div>
              </div>
              <div className="relative w-16 h-16 bg-black rounded-[60px] overflow-hidden">
                <div className="absolute top-[11px] left-[22px] [font-family:'Inter',Helvetica] font-black text-white text-3xl text-center tracking-[-1.20px] leading-[normal] whitespace-nowrap">
                  +
                </div>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-8 relative self-stretch w-full flex-[0_0_auto]">
              <p className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                Yes, we have a dedicated customer support team available to assist you with any questions or issues you
                may have. You can reach out to our support team through email or live chat, and we&#39;ll be happy to
                help.
              </p>
            </div>
          </div>
          <div className="flex flex-col items-start relative self-stretch w-full flex-[0_0_auto] rounded-[20px] overflow-hidden border-2 border-solid border-[#f7f7f7]">
            <div className="flex min-w-[400px] items-center justify-between p-8 relative self-stretch w-full flex-[0_0_auto] bg-[#f7f7f7] rounded-[20px_20px_0px_0px] overflow-hidden">
              <div className="relative w-[1552px] h-[46px]">
                <p className="absolute w-[1552px] -top-px left-0 [font-family:'Inter',Helvetica] font-black text-black text-[38px] tracking-[-1.52px] leading-[normal]">
                  Can I export my expense data?
                </p>
              </div>
              <div className="relative w-16 h-16 bg-black rounded-[60px] overflow-hidden">
                <div className="absolute top-[11px] left-[22px] [font-family:'Inter',Helvetica] font-black text-white text-3xl text-center tracking-[-1.20px] leading-[normal] whitespace-nowrap">
                  +
                </div>
              </div>
            </div>
            <div className="flex items-start gap-2.5 p-8 relative self-stretch w-full flex-[0_0_auto]">
              <p className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                Absolutely! Our expense tracker web app allows you to easily export your expense data in various
                formats, such as CSV or PDF. You can then use this data for your own analysis or for tax purposes.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-wrap h-[1041px] items-center gap-[48px_48px] p-[120px] relative self-stretch w-full bg-white">
        <div className="min-w-[600px] gap-6 flex-1 grow flex flex-col items-start relative">
          <div className="flex items-start gap-2.5 relative self-stretch w-full flex-[0_0_auto]">
            <div className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-[#191919] text-7xl tracking-[-2.88px] leading-[normal]">
              Contact Us
            </div>
          </div>
          <div className="flex-wrap gap-[24px_24px] flex items-start relative self-stretch w-full flex-[0_0_auto]">
            <div className="flex flex-col min-w-64 items-start gap-1 relative flex-1 grow">
              <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-bold text-black text-2xl tracking-[-0.96px] leading-[normal]">
                Email
              </div>
              <div className="relative self-stretch [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
                support@expensetracker.com
              </div>
            </div>
          </div>
          <div className="w-[816px] flex flex-col items-start gap-1 relative flex-[0_0_auto]">
            <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-bold text-black text-2xl tracking-[-0.96px] leading-[normal]">
              Phone
            </div>
            <div className="relative self-stretch [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
              +1 123-456-7890
            </div>
          </div>
          <div className="w-[396px] flex flex-col items-start gap-1 relative flex-[0_0_auto]">
            <div className="relative self-stretch mt-[-1.00px] [font-family:'Inter',Helvetica] font-bold text-black text-2xl tracking-[-0.96px] leading-[normal]">
              Address
            </div>
            <p className="relative self-stretch [font-family:'Inter',Helvetica] font-normal text-black text-2xl tracking-[-0.96px] leading-[normal]">
              123 Main Street, City, State, Country
            </p>
          </div>
        </div>
        <div className="flex flex-col min-w-[762px] max-w-[816px] items-start gap-6 px-12 py-[49px] relative flex-1 grow bg-[#f7f7f7] rounded-[20px] overflow-hidden">
          <div className="flex items-start gap-2.5 relative self-stretch w-full flex-[0_0_auto]">
            <div className="relative flex-1 mt-[-1.00px] [font-family:'Inter',Helvetica] font-black text-black text-5xl tracking-[-1.92px] leading-[normal]">
              Get in Touch
            </div>
          </div>
          <div className="flex items-start gap-2.5 relative self-stretch w-full flex-[0_0_auto]">
            <div className="flex flex-col items-start gap-1 relative flex-1 grow">
              <input
                className="relative w-[355px] h-6 border-[none] [background:none] [font-family:'Inter',Helvetica] font-medium text-black text-base tracking-[1.28px] leading-[normal] p-0 pl-0"
                placeholder="Name"
                type="text"
              />
              <div className="relative self-stretch w-full h-[60px] bg-white rounded-[10px] overflow-hidden">
                <div className="top-[17px] left-6 opacity-25 font-normal text-xl tracking-[-0.80px] whitespace-nowrap absolute [font-family:'Inter',Helvetica] text-black leading-[normal]">
                  John
                </div>
              </div>
            </div>
            <div className="flex flex-col items-start gap-1 relative flex-1 grow">
              <input
                className="relative w-[355px] h-6 border-[none] [background:none] font-medium text-base tracking-[1.28px] [font-family:'Inter',Helvetica] text-black leading-[normal] p-0 pl-0"
                placeholder="Surname"
                type="text"
              />
              <div className="relative self-stretch w-full h-[60px] bg-white rounded-[10px] overflow-hidden">
                <div className="absolute top-[17px] left-6 opacity-25 [font-family:'Inter',Helvetica] font-normal text-black text-xl tracking-[-0.80px] leading-[normal] whitespace-nowrap">
                  Doe
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start gap-1 relative self-stretch w-full flex-[0_0_auto]">
            <div className="relative self-stretch w-full h-6">
              <div className="absolute w-[720px] -top-px left-0 [font-family:'Inter',Helvetica] font-medium text-black text-base tracking-[1.28px] leading-[normal]">
                Mail
              </div>
            </div>
            <div className="relative self-stretch w-full h-[60px] bg-white rounded-[10px] overflow-hidden">
              <div className="absolute top-[17px] left-6 opacity-25 [font-family:'Inter',Helvetica] font-normal text-black text-xl tracking-[-0.80px] leading-[normal] whitespace-nowrap">
                johndoe@mail.net
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start gap-1 relative self-stretch w-full flex-[0_0_auto]">
            <div className="relative self-stretch w-full h-6">
              <div className="absolute w-[720px] -top-px left-0 [font-family:'Inter',Helvetica] font-medium text-black text-base tracking-[1.28px] leading-[normal]">
                Address
              </div>
            </div>
            <div className="relative self-stretch w-full h-[60px] bg-white rounded-[10px] overflow-hidden">
              <div className="absolute top-[17px] left-6 opacity-25 [font-family:'Inter',Helvetica] font-normal text-black text-xl tracking-[-0.80px] leading-[normal] whitespace-nowrap">
                Capitol, WA
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start gap-1 relative self-stretch w-full flex-[0_0_auto]">
            <div className="relative self-stretch w-full h-6">
              <div className="absolute w-[720px] -top-px left-0 [font-family:'Inter',Helvetica] font-medium text-black text-base tracking-[1.28px] leading-[normal]">
                Description
              </div>
            </div>
            <div className="relative self-stretch w-full h-[156px] bg-white rounded-[10px]" />
          </div>
          <button className="all-[unset] box-border flex items-center justify-center gap-2.5 p-6 relative self-stretch w-full flex-[0_0_auto] bg-black rounded-[10px] overflow-hidden">
            <button className="all-[unset] box-border relative flex-1 mt-[-7.00px] [font-family:'Inter',Helvetica] font-bold text-white text-2xl text-center tracking-[-0.96px] leading-[normal]">
              Submit
            </button>
          </button>
        </div>
      </div>
    </div>
  );
};
